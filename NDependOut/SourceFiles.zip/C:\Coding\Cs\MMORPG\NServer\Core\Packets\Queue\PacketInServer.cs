﻿namespace NServer.Core.Packets.Queue
{
    /// <summary>
    /// Hàng đợi gói tin server dùng để xử lý các gói tin gửi.
    /// </summary>
    public class PacketInServer : PacketQueue
    {
        public PacketInServer() : base()
        {
        }
    }
}