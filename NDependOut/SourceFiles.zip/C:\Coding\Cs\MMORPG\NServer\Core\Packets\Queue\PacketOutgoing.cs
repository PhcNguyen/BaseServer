﻿namespace NServer.Core.Packets.Queue
{
    /// <summary>
    /// Hàng đợi gói tin dùng để xử lý các gói tin gửi.
    /// </summary>
    public class PacketOutgoing : PacketQueue
    {
        public PacketOutgoing() : base()
        {
        }
    }
}